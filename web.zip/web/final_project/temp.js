document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM Loaded!"); // kontrol 

  

 document.querySelector("a[href='#info']").addEventListener("click", function(event) {
        event.preventDefault(); 
       // document.querySelector(".right_section").style.display = "block"; // Sağdaki bölümü göster
    });
    
 

    document.querySelector('a[href="#students"]').addEventListener('click', function(event) {
        event.preventDefault();
        fetch('students.json')
            .then(response => response.json())
            .then(data => {
                const students = data.students;
                showStudentsInfo(students);
            })
            .catch(error => console.error('Error:', error));
    });

    function showStudentsInfo(students) {
        let studentTableBody = document.getElementById('studentTableBody');
        studentTableBody.innerHTML = '';

        students.forEach(student => {
            let row = document.createElement('tr');

            row.innerHTML = `
                <td>${student.id}</td>
                <td>${student.name} ${student.surname}</td>
                <td>00</td>
                <td>${student.courses.length >= 3 ? `${student.courses[0].courseName}, ${student.courses[1].courseName}, ${student.courses[2].courseName}` : `${student.courses[0].courseName}, ${student.courses[1].courseName}`}</td>
            `;
            studentTableBody.appendChild(row);
        });

        studentTableBody.parentElement.style.display = 'block';
        document.querySelector(".right_section").style.display = "block"; // Sağdaki bölümü göster
    }


    // SEARCH BUTTON 
    document.querySelector('.search_button').addEventListener('click', function() {

       
        const searchInput = document.querySelector('.search_student input').value.toLowerCase();
         if(searchInput.length<3){
            alert('Please make sure the name you enter is at least 3 letters long.');
        }
        const students = Array.from(document.querySelectorAll('#studentTableBody tr'));
        let found = false; 

        students.forEach(student => {
            const name = student.querySelectorAll('td')[1].textContent.toLowerCase(); // name column
            const surname = student.querySelectorAll('td')[2].textContent.toLowerCase(); // surname column
            student.style.display = 'none'; // all the students are hiden
           

            // input include name and surname
            if (name.includes(searchInput) || surname.includes(searchInput)) {
                 
                student.style.display = 'table-row';
                found = true; // student has been founded
            }
            
        });

        // if the student couldn't found
        if (!found) {
            alert('Student not found!');
        }
    });

    // DELETE BUTTON
    document.querySelector('.delete_button').addEventListener('click', function() {
        const deleteInput = document.querySelector('.delete_student input').value;
        const students = Array.from(document.querySelectorAll('#studentTableBody tr'));
    
        students.forEach(student => {
            const studentID = student.querySelector('td:first-child').textContent;
    
            // Girilen öğrenci ID'sine sahip öğrenciyi sil
            if (studentID === deleteInput) {
                student.remove();
            }
        });
    });





    // linklerle ilgili 
    //

//     const links = document.querySelectorAll(".left_section a");
//     links.forEach((link, index) => {
//         link.addEventListener("click", function(event) {
//             event.preventDefault();
//             links.forEach(item => {
//                 item.classList.remove("active");
//             });
//             this.classList.add("active");
//            document.querySelector(".right_section").style.display = "none"; // Sağdaki bölümü gizle
//             document.querySelectorAll(".right_section > div").forEach(section => {
//                 section.classList.remove("active");
//             });
//         });
//     });
    
// });



     function displayRightSection(page_number) {
       const rightSection = document.querySelector(".right_section");
       rightSection.style.display = "block";

       if (page_number === 0) {
         rightSection.innerHTML = "INFO PAGE";
       }
       if (page_number === 1) {
         rightSection.innerHTML = "ADD COURSE PAGE";
       }
       if (page_number === 2) {
         rightSection.innerHTML = "COURSES PAGE";
       }
       if (page_number === 3) {
         rightSection.innerHTML = "STUDENTS PAGE";
       }
     }

     function handleLinkClicks(event, index) {
       event.preventDefault();
       links.forEach((item) => {
         item.classList.remove("active");
       });
       this.classList.add("active");
       document.querySelectorAll(".right_section > div").forEach((section) => {
         section.classList.remove("active");
       });
       displayRightSection(index);
     }